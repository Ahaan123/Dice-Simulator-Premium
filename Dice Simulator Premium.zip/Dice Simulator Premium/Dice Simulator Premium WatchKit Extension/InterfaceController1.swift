//
//  InterfaceController1.swift
//  Dice Simulator Premium
//
//  Created by Ahaan Pandya on 23/08/2019.
//  Copyright © 2019 Ahaan Pandya. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController1: WKInterfaceController {

    @IBOutlet weak var diceimage: WKInterfaceImage!
    @IBAction func rollTapped() {
        let rand = Int.random(in: 1...6)
        diceimage.setImage(UIImage(named: "dice\(rand)"))
    }
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
