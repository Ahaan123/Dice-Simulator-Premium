//
//  ViewController2.swift
//  Dice Simulator Premium
//
//  Created by Ahaan Pandya on 24/08/2019.
//  Copyright © 2019 Ahaan Pandya. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var diceimageview1: UIImageView!
    @IBOutlet weak var diceimageview2: UIImageView!
    @IBAction func rollButtonClicked(_ sender: Any) {
        let randnum1 = Int.random(in: 1...6)
        let randnum2 = Int.random(in: 1...6)
        diceimageview1.image = UIImage(named: "dice\(randnum1)")
        diceimageview2.image = UIImage(named: "dice\(randnum2)")
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
